import json

def find_best_mentors(user_interests):
    with open("data/mentors.json", "r") as file:
        mentors = json.load(file)
    
    user_interests = [interest.strip().lower() for interest in user_interests.split(",")]

    best_matches = []

    for mentor in mentors:
        mentor_skills = [skill.lower() for skill in mentor["skills"]]
        match_score = sum(1 for interest in user_interests if any(interest in skill for skill in mentor_skills))

        if match_score > 0:
            best_matches.append({
                "name": mentor["name"],
                "skills": mentor["skills"],
                "image": mentor["image"],
                "score": match_score
            })

    best_matches.sort(key=lambda x: x["score"], reverse=True)  # Sort by highest match score

    return best_matches  # Return mentor details
