from flask import Flask, render_template, request
from matching import find_best_mentors

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/match", methods=["POST"])
def match():
    user_interests = request.form.get("interests")

    if not user_interests:
        return render_template("results.html", message="⚠️ Please enter at least one skill.")

    mentors = find_best_mentors(user_interests)

    return render_template("results.html", interests=user_interests, mentors=mentors)

if __name__ == "__main__":
    app.run(debug=True)
